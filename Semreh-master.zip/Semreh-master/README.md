# Semreh
Semreh is a stock market training app, which provides a sandbox for testing various investment strategies. The user is given an initial amount of money and can "invest" this in various stocks. Progress and gains can be monitored by viewing various statistics about both individual and total stock performance.
